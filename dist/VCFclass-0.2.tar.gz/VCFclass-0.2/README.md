# VCFClass

This is a package that allows for easy interaction between VCF files and tools in the Python bioscience ecosystem (pandas, numpy, matplotlib, etc).
